tim1.0即时通讯
email ： donnie4w@gmail.com
------------------------------------
启动说明
1.仅支持在64位操作系统上启动
2.启动前确认数据库是否已经建立，同时建立相关数据库表，doc/tim.sql中有相关表结构
3.启动脚本start 是单机启动命令
4.启动脚本start-cluster 是集群启动命令，集群依赖redis，需先启动redis，并在tim-cluster.xml中配置相关redis的验证信息